<?php

namespace App\Repositories;

class EventRepository {}